// const element = document.getElementsByTagName("p");

// document.getElementById("demo").innerHTML = 'hello world: ' + element[2].innerHTML;

// var para = document.getElementsByClassName("para");

// console.log(para[2])

// var para = document.getElementsByClassName("p1")

// console.log(para[4])



















function changeImage(){
   var img = document.getElementById('image');
   img.style.width = "1000px";
   img.src = "https://img.freepik.com/free-vector/modern-blue-urban-adventure-suv-vehicle-illustration_1344-205.jpg?w=2000";
   console.log(img)
}


function changeImage2(){
   var img = document.getElementById('image');
   img.src = "https://i.gaw.to/content/photos/56/76/567681-lamborghini-revuelto-une-nouvelle-bombe-hybride-de-1001-chevaux.jpeg";
   console.log(img)
}




















